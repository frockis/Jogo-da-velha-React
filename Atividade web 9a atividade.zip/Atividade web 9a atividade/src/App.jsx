import { useState } from 'react'
import './App.css'

// Você joga com X. O computador responde com O na mesma jogada.
const JOGADOR = 'X'
const COMPUTADOR = 'O'

// Todas as linhas que fecham o jogo: 3 horizontais, 3 verticais e 2 diagonais.
const LINHAS = [
  [0, 1, 2],
  [3, 4, 5],
  [6, 7, 8],
  [0, 3, 6],
  [1, 4, 7],
  [2, 5, 8],
  [0, 4, 8],
  [2, 4, 6],
]

function tabuleiroVazio() {
  return Array(9).fill(null)
}

function quemGanhou(tabuleiro) {
  for (const linha of LINHAS) {
    const [a, b, c] = linha
    const peca = tabuleiro[a]

    if (peca && peca === tabuleiro[b] && peca === tabuleiro[c]) {
      return { peca, linha }
    }
  }

  return { peca: null, linha: [] }
}

function casasVazias(tabuleiro) {
  return tabuleiro
    .map((valor, indice) => (valor === null ? indice : null))
    .filter((indice) => indice !== null)
}

// Procura uma casa que faria "peca" ganhar agora.
function casaParaGanhar(tabuleiro, peca) {
  for (const indice of casasVazias(tabuleiro)) {
    const copia = [...tabuleiro]
    copia[indice] = peca

    if (quemGanhou(copia).peca === peca) {
      return indice
    }
  }

  return null
}

function jogadaDoComputador(tabuleiro) {
  const paraVencer = casaParaGanhar(tabuleiro, COMPUTADOR)
  if (paraVencer !== null) return paraVencer

  const paraBloquear = casaParaGanhar(tabuleiro, JOGADOR)
  if (paraBloquear !== null) return paraBloquear

  if (tabuleiro[4] === null) return 4

  const cantos = [0, 2, 6, 8].filter((indice) => tabuleiro[indice] === null)
  if (cantos.length > 0) {
    return cantos[Math.floor(Math.random() * cantos.length)]
  }

  const vazias = casasVazias(tabuleiro)
  return vazias[Math.floor(Math.random() * vazias.length)]
}

function Casa({ indice, valor, destaque, desativada, onClick }) {
  const classe = ['casa', valor === 'X' ? 'x' : '', valor === 'O' ? 'o' : '', destaque ? 'destaque' : '']
    .filter(Boolean)
    .join(' ')
  const nome = valor ? `Casa ${indice + 1}: ${valor}` : `Casa ${indice + 1}, vazia`

  return (
    <button type="button" className={classe} aria-label={nome} onClick={onClick} disabled={desativada}>
      {valor}
    </button>
  )
}

export default function App() {
  const [tabuleiro, setTabuleiro] = useState(tabuleiroVazio)
  const [placar, setPlacar] = useState({ voce: 0, computador: 0, empates: 0 })

  const { peca: vencedor, linha: linhaVencedora } = quemGanhou(tabuleiro)
  const empate = !vencedor && casasVazias(tabuleiro).length === 0
  const jogoAcabou = Boolean(vencedor) || empate

  function registrarPlacar(novoTabuleiro) {
    const ganhou = quemGanhou(novoTabuleiro).peca

    if (ganhou === JOGADOR) {
      setPlacar((atual) => ({ ...atual, voce: atual.voce + 1 }))
    } else if (ganhou === COMPUTADOR) {
      setPlacar((atual) => ({ ...atual, computador: atual.computador + 1 }))
    } else if (casasVazias(novoTabuleiro).length === 0) {
      setPlacar((atual) => ({ ...atual, empates: atual.empates + 1 }))
    }
  }

  function clicarCasa(indice) {
    if (tabuleiro[indice] !== null || jogoAcabou) return

    const proximo = [...tabuleiro]
    proximo[indice] = JOGADOR

    const jogadorEncerrou = quemGanhou(proximo).peca || casasVazias(proximo).length === 0
    if (!jogadorEncerrou) {
      proximo[jogadaDoComputador(proximo)] = COMPUTADOR
    }

    setTabuleiro(proximo)
    registrarPlacar(proximo)
  }

  function novaPartida() {
    setTabuleiro(tabuleiroVazio())
  }

  let mensagem = 'Sua vez. Você é o X.'
  if (vencedor === JOGADOR) mensagem = 'Você ganhou!'
  else if (vencedor === COMPUTADOR) mensagem = 'O computador ganhou.'
  else if (empate) mensagem = 'Deu empate.'

  return (
    <main className="pagina">
      <h1>Jogo da Velha</h1>
      <p className="subtitulo">Você contra o computador. Toda a partida acontece aqui no navegador.</p>

      <p className="mensagem" role="status">
        {mensagem}
      </p>

      <div className="tabuleiro" role="grid" aria-label="Tabuleiro">
        {tabuleiro.map((valor, indice) => (
          <Casa
            key={indice}
            indice={indice}
            valor={valor}
            destaque={linhaVencedora.includes(indice)}
            desativada={valor !== null || jogoAcabou}
            onClick={() => clicarCasa(indice)}
          />
        ))}
      </div>

      <button type="button" className="reiniciar" onClick={novaPartida}>
        Nova partida
      </button>

      <section className="placar" aria-label="Placar">
        <p>
          Você <strong>{placar.voce}</strong>
        </p>
        <p>
          Empates <strong>{placar.empates}</strong>
        </p>
        <p>
          Computador <strong>{placar.computador}</strong>
        </p>
      </section>
    </main>
  )
}
